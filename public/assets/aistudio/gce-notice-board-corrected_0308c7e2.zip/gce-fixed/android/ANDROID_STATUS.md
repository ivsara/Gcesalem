# Android companion status

The original Jetpack Compose sources are retained. The manifest now declares `INTERNET`, and `data/remote/NoticeBoardApi.kt` defines Retrofit contracts for login, notices, role-protected CRUD and multipart attachment upload against the FastAPI API.

## Configure backend URL

The default `API_BASE_URL` is `http://10.0.2.2:8000/` for the Android Studio emulator. For a physical phone, override the Gradle property with the development computer's LAN address, for example:

```bash
./gradlew assembleDebug -PAPI_BASE_URL=http://192.168.1.20:8000/
```

Keep the phone and computer on the same trusted network. The manifest currently permits cleartext HTTP for local development; remove `android:usesCleartextTraffic="true"` and use HTTPS for deployment.

## Build status / limitation

This environment did not contain an Android SDK, Gradle executable, Gradle wrapper scripts, or `gradle-wrapper.jar`, so an Android Gradle compilation could not be run or certified. The web app is the fully implemented primary client. The legacy Compose screens still need to be migrated from their local Room data source to `NoticeBoardApiClient.service` before claiming that the old Android UI is fully synchronized with the backend. The Retrofit contract and multipart endpoint are provided, but the old screens do not yet invoke them.

To verify locally in Android Studio: open this `android/` directory as the project, allow Gradle sync, install Android SDK 36, then run `:app:assembleDebug`. Resolve any remaining source/dependency errors reported by that actual build before distributing an APK.
